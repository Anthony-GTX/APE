// Ejercicio 1: Libro y Autor (objeto como atributo)

class Autor {
    String nombre;
    String nacionalidad;

    Autor(String nombre, String nacionalidad) {
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
    }
}

class Libro {
    String titulo;
    int anio;
    Autor autor; // objeto como atributo

    Libro(String titulo, int anio, Autor autor) {
        this.titulo = titulo;
        this.anio = anio;
        this.autor = autor;
    }

    void mostrarInformacion() {
        System.out.println("Titulo: " + titulo);
        System.out.println("Anio: " + anio);
        System.out.println("Autor: " + autor.nombre);
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        Autor autor1 = new Autor("Gabriel Garcia Marquez", "Colombiana");
        Autor autor2 = new Autor("Julio Verne", "Francesa");

        Libro libro1 = new Libro("Cien anos de soledad", 1967, autor1);
        Libro libro2 = new Libro("Viaje al centro de la Tierra", 1864, autor2);

        libro1.mostrarInformacion();
        libro2.mostrarInformacion();
    }
}
