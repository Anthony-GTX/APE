// Ejercicio 5: Biblioteca (colaboracion entre clases)

class Usuario {
    String nombre;
    String cedula;

    Usuario(String nombre, String cedula) {
        this.nombre = nombre;
        this.cedula = cedula;
    }
}

class Libro {
    String titulo;
    boolean disponible = true;

    Libro(String titulo) {
        this.titulo = titulo;
    }

    boolean prestar() {
        if (disponible) {
            disponible = false;
            return true;
        }
        return false;
    }

    void devolver() {
        disponible = true;
    }
}

class Prestamo {
    Usuario usuario;
    Libro libro;

    Prestamo(Usuario usuario, Libro libro) {
        this.usuario = usuario;
        this.libro = libro;
    }

    void registrar() {
        if (libro.prestar()) {
            System.out.println(usuario.nombre + " recibio: " + libro.titulo);
        } else {
            System.out.println("Libro no disponible para " + usuario.nombre);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Libro libro = new Libro("Java basico");
        Usuario usuario1 = new Usuario("Ana", "123");
        Usuario usuario2 = new Usuario("Luis", "456");

        Prestamo prestamo1 = new Prestamo(usuario1, libro);
        Prestamo prestamo2 = new Prestamo(usuario2, libro);

        prestamo1.registrar();
        prestamo2.registrar();
    }
}
