// Ejercicio 3: Producto y Venta (objeto como parametro)

class Producto {
    String nombre;
    double precio;
    int stock;

    Producto(String nombre, double precio, int stock) {
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
    }

    // Reduce el stock solo si hay suficiente
    boolean reducirStock(int cantidad) {
        if (cantidad > 0 && cantidad <= stock) {
            stock = stock - cantidad;
            return true;
        } else {
            System.out.println("Stock insuficiente.");
            return false;
        }
    }

    void mostrarProducto() {
        System.out.println(nombre + " | Precio: " + precio + " | Stock: " + stock);
    }
}

class Venta {
    int cantidad;

    Venta(int cantidad) {
        this.cantidad = cantidad;
    }

    // Recibe un objeto Producto como parametro
    void aplicar(Producto producto) {
        if (producto.reducirStock(cantidad)) {
            double total = producto.precio * cantidad;
            System.out.println("Total a pagar: " + total);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Producto laptop = new Producto("Laptop", 500, 10);

        Venta venta1 = new Venta(2);
        venta1.aplicar(laptop);
        laptop.mostrarProducto();

        Venta venta2 = new Venta(20);
        venta2.aplicar(laptop);
        laptop.mostrarProducto();
    }
}
