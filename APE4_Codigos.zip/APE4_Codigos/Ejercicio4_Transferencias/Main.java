// Ejercicio 4: Transferencias entre cuentas (objeto como parametro)

class Cuenta {
    String titular;
    double saldo;

    Cuenta(String titular, double saldo) {
        this.titular = titular;
        this.saldo = saldo;
    }

    // Retira de esta cuenta y deposita en la cuenta destino si hay fondos
    void transferir(Cuenta destino, double monto) {
        if (monto > 0 && saldo >= monto) {
            saldo = saldo - monto;
            destino.saldo = destino.saldo + monto;
            System.out.println("Transferencia exitosa.");
        } else {
            System.out.println("Fondos insuficientes.");
        }
    }

    void mostrar() {
        System.out.println(titular + ": $" + saldo);
    }
}

public class Main {
    public static void main(String[] args) {
        Cuenta cuenta1 = new Cuenta("Ana", 100);
        Cuenta cuenta2 = new Cuenta("Luis", 50);

        cuenta1.transferir(cuenta2, 30);   // transferencia valida
        cuenta1.transferir(cuenta2, 200);  // transferencia que falla

        cuenta1.mostrar();
        cuenta2.mostrar();
    }
}
